include specs.e
